package com.devlabs.lab1; //package declaration

public class HelloWorld //main class name and the java file name has to be same always.
{
    public static void main(String[] args) //method signature 
    //public - everyone can access it.
    //static - I don't need an object to call this method.
    //void - empty - I am not returning anything from this method.
    
    //starting point of execution - JVM - 
    //java virtual machine will look for this method to start executing our code
    {
        System.out.println("Deepti");
        System.out.println("Welcome");
    }
}
