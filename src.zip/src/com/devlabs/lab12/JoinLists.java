package com.devlabs.lab12;

import java.util.ArrayList;
import java.util.LinkedList;
import java.util.List;

public class JoinLists {

	
    public static void main(String[] args) {
	        List item1 = new ArrayList();
	        
	        item1.add("Pavan");
	        item1.add("Kumar");
	        item1.add("Moram");
	        
	        List item2 = new ArrayList();
	        
	        item2.add("Yellow");
	        item2.add("Red");
	        item2.add("Green");
	        
	// addall to item1      
	        item1.addAll(item2);
	        
	         for(int j=0;j<item1.size();j++)
	           {  
	             System.out.println("" +item1.get(j)); 
	           }  

	        
	        
	    }

	}


