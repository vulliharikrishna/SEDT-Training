package com.devlabs.lab3;

public interface PrimeInterface 
{
   public void checkPrime(int a);
}
