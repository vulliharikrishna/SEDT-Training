package com.devlabs.lab2;

public class SwapNumbers {

    public static void main(String[] args) {
        // TODO Auto-generated method stub
        float a = 10.31f;
        float b = 2.69f;
        float c ;
        c=a;
        a=b;
        b=c;
        System.out.println(a);
        System.out.println(b);
        
    }

}
 
